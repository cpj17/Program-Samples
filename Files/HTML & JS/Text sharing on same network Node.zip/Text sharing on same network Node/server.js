const WebSocket = require('ws');
const http = require('http');

// Create an HTTP server to host WebSocket connections
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('WebSocket server is running');
});

// Create a WebSocket server attached to the HTTP server
const wss = new WebSocket.Server({ server });

// Handle new WebSocket connections
wss.on('connection', (ws) => {
  console.log('A client connected');

  // Handle incoming messages
  ws.on('message', (message) => {
    // Check if message is a Blob
    if (Buffer.isBuffer(message)) {
      console.log(`Received a Blob: ${message.toString('utf-8')}`);
      // Broadcast the Blob message to all other clients
      wss.clients.forEach((client) => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    } else {
      console.log(`Received: ${message}`);
      // Broadcast the text message to all other clients
      wss.clients.forEach((client) => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    }
  });

  // Send a welcome message to the new client
  ws.send('Welcome to the WebSocket server!');
});

// Start the HTTP server on a specific port
server.listen(8080, () => {
  console.log('Server is listening on port 8080');
});
