how to run

open terminal in vs code and type node server.js hit enter
then run html file using live server