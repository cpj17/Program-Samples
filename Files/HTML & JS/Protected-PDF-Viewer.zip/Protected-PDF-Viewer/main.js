// Prevent right-click
document.addEventListener('contextmenu', function(e) {
	e.preventDefault();
});

// PDF.js configuration
const url = 'a.pdf';  // Replace with the path to your PDF
const pdfjsLib = window['pdfjs-dist/build/pdf'];

// Function to render each page
function renderPage(page, container) {
	const scale = 1.5;
	const viewport = page.getViewport({ scale: scale });

	// Create a new canvas element
	const canvas = document.createElement('canvas');
	const context = canvas.getContext('2d');
	canvas.height = viewport.height;
	canvas.width = viewport.width;
	container.appendChild(canvas);

	// Render PDF page into canvas context
	const renderContext = {
		canvasContext: context,
		viewport: viewport
	};
	page.render(renderContext);
}

// Asynchronous download of PDF
pdfjsLib.getDocument(url).promise.then(function(pdf) {
	const pdfContainer = document.getElementById('pdf-container');

	// Loop through each page and render it
	for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
		pdf.getPage(pageNumber).then(function(page) {
			renderPage(page, pdfContainer);
		});
	}
});

// Disable right-click context menu
document.addEventListener('contextmenu', function(e) {
	e.preventDefault();
});

// Disable specific keyboard shortcuts (Ctrl+P, Ctrl+S, Ctrl+U)
document.addEventListener('keydown', function(e) {
	if (e.ctrlKey && (e.key === 'p' || e.key === 's' || e.key === 'u')) {
		e.preventDefault();
	}
});

// Prevent text selection using JavaScript
document.addEventListener('selectstart', function(e) {
	e.preventDefault();
});