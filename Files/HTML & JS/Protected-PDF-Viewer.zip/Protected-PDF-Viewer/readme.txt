If you want to run locally then it will work only in disabled chrome use below command to open
"C:\Program Files\Google\Chrome\Application\chrome.exe" --disable-web-security --user-data-dir="C:\tmpChromeSession"

If you want run locally without disabled chrome then have to deploy your pc use pc iis