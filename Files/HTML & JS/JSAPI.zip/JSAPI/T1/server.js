const express = require('express');
const fs = require('fs').promises; // Using promises version of fs for asynchronous file operations

const app = express();
app.use(express.json()); // Middleware to parse JSON request bodies

// Define a route to handle POST requests to write text to a file
app.post('/api/writefile', async (req, res) => {
    try {
        // Extract text from the request body
        const { text } = req.body;

        // Check if text is provided
        if (!text) {
            return res.status(400).json({ error: 'Text is required' });
        }

        // Write text to a file
        await fs.writeFile('output.txt', text);

        // Respond with a success message
        res.json({ message: 'Text written to file successfully' });
    } catch (error) {
        // If an error occurs, respond with an error message
        console.error('Error writing to file:', error);
        res.status(500).json({ error: 'An error occurred while writing to file' });
    }
});

// Start the server and listen on a port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
