// JavaScript source code

function pageload() {
    try {
        if (localStorage.getItem("lsLoginTimestamp") != null || localStorage.getItem("lsLoginCustomerSeletedTimestamp") != null) {
            showBootboxDialogWithCallbackFunction(stringMoreThanOneLoginMsg, "LOGIN", "", "Info", "large")
        }

        sessionStorage.clear()

        getConfigJSON()
        sessionStorage.setItem("pgno", 1)
    } catch (objError) {
        handleCatchError(objError)
    }
}

function GRN() {
    try {
       
        window.location = 'WOPO0103R1V1.html'
    } catch (objError) {
        handleCatchError(objError)
    }
}

