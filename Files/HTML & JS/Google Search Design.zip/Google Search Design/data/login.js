// JavaScript source code

var intInvalidLoginCount = 0
var intMaxRetries = 5
var stringCustomerID = ""
var stringCustomerName = ""
var intPagePerRecord = 10000
var intPageBtnRepeater = 5
var stringSelectedCustomerStatus = ""
stringMoreThanOneLoginMsg = "You're already logged, Do you want to proceed further please logout to continue. Click Close button or X symbol to logout"
stringSessionClearMsg = "Your Session is Expired"

function pageload() {
    try {
        if (localStorage.getItem("lsLoginTimestamp") != null || localStorage.getItem("lsLoginCustomerSeletedTimestamp") != null) {
            showBootboxDialogWithCallbackFunction(stringMoreThanOneLoginMsg, "LOGIN", "", "Info", "large")
        }

        sessionStorage.clear()

        getConfigJSON()
        sessionStorage.setItem("pgno", 1)
    } catch (objError) {
        handleCatchError(objError)
    }
}

function login() {
    try {
        window.location ='Index.html'
    } catch (objError) {
        handleCatchError(objError)
    }
}
