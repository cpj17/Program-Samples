replace the both Default.apsx and Default.apsx.cs into existing one

and the script works in sitemaster.aspx file too