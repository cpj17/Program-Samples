﻿using System;
using System.Net;

namespace Grievances
{
    public partial class PgVwFile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                string strRefPage = "";
                if (Request.UrlReferrer != null)
                {
                    strRefPage = Request.UrlReferrer.Segments[Request.UrlReferrer.Segments.Length - 1];
                }
                if (Session["userid"] == null || strRefPage == "" || Session["FilePath"] == null || Session["Filepath"].ToString() == "")
                {
                    Response.Redirect("~/Login.aspx");
                }
                else
                {
                    string FilePath = Session["Filepath"].ToString();
                    WebClient User = new WebClient();
                    Byte[] FileBuffer = User.DownloadData(FilePath);

                    if (FileBuffer != null)
                    {
                        string fileExtension = System.IO.Path.GetExtension(FilePath).ToLower();

                        // Check the file extension and set the Content-Type accordingly
                        if (fileExtension == ".pdf")
                        {
                            Response.ContentType = "application/pdf";
                        }
                        else if (fileExtension == ".jpg" || fileExtension == ".jpeg")
                        {
                            Response.ContentType = "image/jpeg";
                        }
                        else if (fileExtension == ".png")
                        {
                            Response.ContentType = "image/png";
                        }
                        else if (fileExtension == ".gif")
                        {
                            Response.ContentType = "image/gif";
                        }
                        else if (fileExtension == ".bmp")
                        {
                            Response.ContentType = "image/bmp";
                        }
                        else
                        {
                            // Handle unsupported types or fallback
                            Response.ContentType = "application/octet-stream"; // Default binary stream
                        }

                        Response.AddHeader("content-length", FileBuffer.Length.ToString());
                        Response.BinaryWrite(FileBuffer);
                    }
                }

            }
        }
    }
}